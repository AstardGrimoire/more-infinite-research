Trickle down economics bring productivity gains to all industries!
Adds infinite productivity research for intermediates and other useful ingredients not covered by existing vanilla, Space Age, or modded productivity researches. Uncapped research levels but +300% engine cap applies.
Adds Space Age productivity techs to the vanilla base game where missing.
Each technology can be individually disabled if you don't like them.
This mod was created to make mega-basing a bit easier on low end hardware.
If you have any suggestions for changes or mod compatibility or additions let me know.
