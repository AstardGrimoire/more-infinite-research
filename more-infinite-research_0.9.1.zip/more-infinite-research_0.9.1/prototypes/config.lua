local M = {}

-- Shared curve (identical for all techs; same packs and time every level)
M.shared = {
  per_level_default = 0.10, -- streams with grouped changes override per group
  base_cost      = 8000,
  growth_factor  = 2,       -- 100% increase per level
  research_time  = 60
}

-- Streams (no tiers/stages; keys are research_*)
M.streams = {
  -- machine/category-wide (category/entity ids may come from mods)
  research_breeding = {
    mode="by_category_or_match",
    match = { categories={"fish-breeding","biter-breeding","pentapod-breeding"}, name_patterns={"breeding","spawner"} },
    icon_item = "raw-fish"
  },
  research_farming = {
    mode="by_entity_or_category",
    entities={"agricultural-tower"},
    categories={"agriculture","farming"},
    icon_item = "fertilizer"
  },

  -- core intermediates (vanilla-correct names)
  research_plastic              = { items={"plastic-bar"},        icon_item="plastic-bar" },
  research_sulfur               = { icon_tech="sulfur-processing",  items={"sulfur"},             icon_item="sulfur" },
  research_batteries            = { icon_tech="battery",  items={"battery"},            icon_item="battery" },
  research_explosives           = { icon_tech="explosives",  items={"explosives"},         icon_item="explosives" },
  research_gears                = { items={"iron-gear-wheel"},    icon_item="iron-gear-wheel" },
  research_iron_sticks          = { items={"iron-stick"},         icon_item="iron-stick" },
  research_copper_cable         = { items={"copper-cable"},       icon_item="copper-cable" },
  research_electronic_circuit   = { icon_tech="electronics",  items={"electronic-circuit"}, icon_item="electronic-circuit" },
  research_advanced_circuit     = { icon_tech="advanced-electronics",  items={"advanced-circuit"},   icon_item="advanced-circuit" },

  -- items added to vanilla if missing in base (Space Age adds these)
  research_processing_unit      = { icon_tech="advanced-electronics-2",  items={"processing-unit"},         icon_item="processing-unit" },
  research_low_density_structure= { items={"low-density-structure"},   icon_item="low-density-structure" },
  research_rocket_fuel          = { items={"rocket-fuel"},             icon_item="rocket-fuel" },

  -- metals and late intermediates
  research_copper               = { icon_tech="advanced-material-processing",  items={"copper-plate"},        icon_item="copper-plate" },
  research_iron                 = { icon_tech="advanced-material-processing",  items={"iron-plate"},          icon_item="iron-plate" },
  research_engine               = { icon_tech="engine",  items={"engine-unit"},         icon_item="engine-unit" },
  research_electric_engine      = { icon_tech="electric-engine",  items={"electric-engine-unit"}, icon_item="electric-engine-unit" },
  research_flying_robot_frame   = { icon_tech="robotics",  items={"flying-robot-frame"},  icon_item="flying-robot-frame" },

  -- overhaul/space-age items (common ids)
  research_tungsten             = { icon_tech="tungsten-processing",  items={"tungsten-plate","tungsten-carbide"}, icon_item="tungsten-plate" },
  research_holmium              = { icon_tech="holmium-processing",  items={"holmium-plate"},       icon_item="holmium-plate" },
  research_supercapacitor       = { icon_tech="supercapacitor",  items={"supercapacitor"},      icon_item="supercapacitor" },
  research_superconductor       = { icon_tech="superconductor",  items={"superconductor"},      icon_item="superconductor" },
  research_bioflux              = { icon_tech="bioflux",  items={"bioflux"},             icon_item="bioflux" },
  research_carbon_fiber         = { items={"carbon-fiber"},        icon_item="carbon-fiber" },
  research_lithium              = { icon_tech="lithium-processing",  items={"lithium-plate"},       icon_item="lithium-plate" },
  research_quantum_processor    = { icon_tech="quantum-processor",  items={"quantum-processor"},   icon_item="quantum-processor" },

  -- merged categories with graded per-group changes
  research_modules = { icon_tech="productivity-module", 
    icon_item="productivity-module", -- tier 1 productivity module icon
    groups = {
      { change=0.10, items={"productivity-module","speed-module","efficiency-module"} },
      { change=0.05, items={"productivity-module-2","speed-module-2","efficiency-module-2"} },
      { change=0.02, items={"productivity-module-3","speed-module-3","efficiency-module-3"} },
      { change=0.01, item_patterns={"%-module%-4$"} }
    }
  },

  research_belts = { icon_tech="logistics", 
    icon_item="transport-belt",
    groups = {
      { change=0.10, items={"transport-belt","underground-belt","splitter"} },
      { change=0.05, items={"fast-transport-belt","fast-underground-belt","fast-splitter"} },
      { change=0.02, items={"express-transport-belt","express-underground-belt","express-splitter"} },
      { change=0.01, item_patterns={"^turbo%-%a+belt","^turbo%-%a+splitter","^ultimate%-%a+belt","^ultimate%-%a+splitter"} }
    }
  },

  research_inserters = { icon_tech="automation", 
    icon_item="inserter",
    groups = {
      { change=0.10, items={"inserter","burner-inserter"} },
      { change=0.05, items={"fast-inserter","long-handed-inserter"} },
      { change=0.02, items={"bulk-inserter"}, item_patterns={"bulk%-inserter"} },
      { change=0.01, items={"stack-inserter"}, item_patterns={"stack%-inserter"} }
    }
  },

  research_bullets = { icon_tech="military", 
    icon_item="firearm-magazine",
    groups = {
      { change=0.10, items={"firearm-magazine","shotgun-shell"} },
      { change=0.05, items={"piercing-rounds-magazine","piercing-shotgun-shell"} },
      { change=0.02, items={"uranium-rounds-magazine","uranium-shotgun-shell"} },
      { change=0.01, item_patterns={"^plutonium%-.+magazine$","^plutonium%-.+shotgun%-shell$"} }
    }
  },

  research_rockets = { icon_tech="rocketry", 
    icon_item="rocket",
    groups = {
      { change=0.10, items={"rocket"} },
      { change=0.05, items={"explosive-rocket"} },
      { change=0.02, item_patterns={"^uranium%-rocket$"} },
      { change=0.01, item_patterns={"^plutonium%-rocket$"} }
    }
  }
}

return M
